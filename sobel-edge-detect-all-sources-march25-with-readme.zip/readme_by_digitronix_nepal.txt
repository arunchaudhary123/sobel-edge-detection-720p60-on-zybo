
If you are following the steps on the Video Tutorial of "Video Processing with FPGA" Udemy Course then no need to follow this "readme" steps.

Else , have to follow this steps for "Synthesizing the HLS Sobel Project":

The sources on this folder are the HLS sources, 

While synthesizing the HLS project with this source, the directives must be added.

For adding the directive on the HLS project, here are the steps:
	1. goto "Directive" panel
	2. click on the "stream_in" and "stream_out" and right click on it.
	3. Select [click on] the, "Insert Directive"	
	
	4. In the Directive Option select "Interface". You will see the "sobel_edge_detect.cpp" source has been updated automatically with pragma directive.
	5. in the Destination Option select "Source File" , 
	6. and in the Mode option select "axis".
	7. Now Click "OK".
	After doing this step 1-7, you will see this lines on the "sobel_edge_detect.cpp" sources in line number 5-7:
		#pragma HLS INTERFACE axis register both port=stream_out
		#pragma HLS INTERFACE axis register both port=stream_in
		#pragma HLS DATAFLOW
	
	
	
	
	8. Now you can click on "Run C Synthesis" and/or "Run C Simulation" and "Export RTL" option.